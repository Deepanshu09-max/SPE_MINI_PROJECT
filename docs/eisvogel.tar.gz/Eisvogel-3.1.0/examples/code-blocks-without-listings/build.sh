pandoc "document.md" -o "document.pdf" --from markdown --template "../../dist/eisvogel.latex" --highlight-style kate
